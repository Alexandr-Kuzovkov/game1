<?php
	define('DATA_DIR', 'J:/temp/weather_data/data/gsod/');
	define('STATIONS_FILE', '../data/isd-history.csv');
	define('DB_DIR', 'db/');